<div id="welcome-msg" class="home" style="height: 800px;">
	<div class="wrapper">
		<div class="parawrap">
			<p id="firstline"></p>
			<p id="secondline"></p>
			<p id="thirdline">
				<a href="#/who-do-you-want-to-be-friends-with"><span class="curb"></span> <span class="round" style="display: none;">&#8594;</span></a>
			</p>
		</div>
	</div>
</div>