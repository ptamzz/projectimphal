<div class="isotope home">
	<div id="first-card" class="each-page inview" data-slidestate="true">
		<div class="one card-text" style="top: 80px; width: 700px;">
			<p>Hello, my name is Thoibi.</p>
			<p>I'm from Manipur, a small state in north-east India.</p>

			<p>
				In light of racial prejudice observed in several cities of India recently,
				I'm here to share you some information about the North East.
			</p>
		</div>

		<div class="two card-text" style="top: 140px; width: 500px;">
			<p>First let us try and understand a little about racial slurs.</p>
		</div>
		</div>
	</div>
</div>